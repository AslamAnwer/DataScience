package videoread;

import org.opencv.core.Core;
import org.opencv.core.Mat;
import org.opencv.imgcodecs.Imgcodecs;
import org.opencv.videoio.VideoCapture;

import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.image.BufferedImage;
import java.awt.image.DataBufferByte;
import java.awt.image.WritableRaster;
import java.io.File;
import java.io.IOException;
import java.nio.file.Paths;

public class FrameRead {

	private static final String VIDEO_PATH = "C:\\SampleVideo.mp4";
	private static final String FRAME_OUTPUT_DIR = "D:\\opencv\\frames\\";

	public static void main(String[] args) {
		System.loadLibrary(Core.NATIVE_LIBRARY_NAME);
		if (!Paths.get(VIDEO_PATH).toFile().exists()) {
			System.out.println("File " + VIDEO_PATH + " does not exist!");
			return;
		}

		VideoCapture camera = new VideoCapture(VIDEO_PATH);
		camera.open(VIDEO_PATH);
		// camera.open(0);
		if (!camera.isOpened()) {
			System.out.println("Error! Camera can't be opened!");
			return;
		}
		Mat frame = new Mat();
		int i = 0;
		while (camera.isOpened()) {
			if (camera.read(frame)) {
				System.out.println("Captured Frame Width " + frame.width() + " Height " + frame.height());
//				Imgcodecs.imwrite("camera.jpg", frame);
				BufferedImage bufferedImage = matToBufferedImage(frame);

				File outputfile = new File(FRAME_OUTPUT_DIR + "image" + i + ".jpg");
				try {
					ImageIO.write(bufferedImage, "jpg", outputfile);
					System.out.println("Wrote the image " + outputfile.getName());
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

				// showWindow(bufferedImage);
			}
			i++;
		}
		camera.release();
	}

	private static BufferedImage matToBufferedImage(Mat frame) {
		int type = 0;
		if (frame.channels() == 1) {
			type = BufferedImage.TYPE_BYTE_GRAY;
		} else if (frame.channels() == 3) {
			type = BufferedImage.TYPE_3BYTE_BGR;
		}
		BufferedImage image = new BufferedImage(frame.width(), frame.height(), type);
		WritableRaster raster = image.getRaster();
		DataBufferByte dataBuffer = (DataBufferByte) raster.getDataBuffer();
		byte[] data = dataBuffer.getData();
		frame.get(0, 0, data);
		return image;
	}

	private static void showWindow(BufferedImage img) {
		JFrame frame = new JFrame();
		frame.getContentPane().add(new JLabel(new ImageIcon(img)));
		frame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
		frame.setSize(img.getWidth(), img.getHeight() + 30);
		frame.setTitle("Image captured");
		frame.setVisible(true);
	}
}
